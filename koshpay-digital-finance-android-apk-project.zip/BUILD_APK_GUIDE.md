# KoshPay Digital Finance — Android APK Build Guide

**Package ID:** `com.koshpay.finance`  
**Version:** `1.0.0` (Build `1`)

## Option 1: Zero-Install Cloud APK Build (GitHub Actions — Easiest)
1. Upload the extracted folder to a GitHub repository.
2. Open the **Actions** tab on GitHub and run **Build Android APK** (or push to `main`).
3. Download the compiled `app-debug.apk` directly from the workflow **Artifacts** section and install it on your Android phone.

## Option 2: Instant Android Install (No APK File Needed)
Open the live web app URL in **Google Chrome on Android**, tap the **⋮ menu → Add to Home screen / Install app**. It installs as a standalone offline Android app with the KoshPay icon.

## Option 3: Local Build with Android Studio
**Prerequisites:** Node.js 18+, Android Studio (Android SDK 34 & JDK 17).
1. Extract this ZIP and run:
   ```bash
   npm install
   npm run build
   rm -rf android
   npx cap add android
   npx cap sync android
   ```
2. Open in Android Studio (`npx cap open android`) and click **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run:
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
   Output APK: `android/app/build/outputs/apk/debug/app-debug.apk`
