import React, { useState } from 'react';
import {
  Check,
  Cloud,
  Copy,
  Download,
  Globe,
  Smartphone,
  Terminal,
  X,
} from 'lucide-react';
import { Language } from '../types/finance';

type GuideTab = 'pwabuilder' | 'capacitor' | 'cloud';

interface ApkInstructionsModalProps {
  open: boolean;
  onClose: () => void;
  lang: Language;
  appName: string;
  packageId: string;
  version: string;
  isExportingApk: boolean;
  onDownloadZip: () => Promise<void>;
}

export const ApkInstructionsModal: React.FC<ApkInstructionsModalProps> = ({
  open,
  onClose,
  lang,
  appName,
  packageId,
  version,
  isExportingApk,
  onDownloadZip,
}) => {
  const [tab, setTab] = useState<GuideTab>('pwabuilder');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!open) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const sanitizedPkg = packageId.trim() || 'com.koshpay.finance';

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 2000);
    } catch {
      // Fallback ignored if clipboard permission denied
    }
  };

  const capacitorCommands = `npm install\nnpm run build\nrm -rf android\nnpx cap add android\nnpx cap sync android\nnpx cap open android`;
  const gradleCommand = `cd android && ./gradlew assembleDebug`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 p-3 sm:p-5"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-white rounded-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#002E6E] text-white px-5 py-4 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5 text-sky-300" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-bold font-display truncate">
                {lang === 'mr'
                  ? 'Android APK तयार करण्याची मार्गदर्शिका'
                  : 'Generate Android APK — Step-by-Step Guide'}
              </h2>
              <p className="text-[11px] text-blue-200 font-mono-num truncate">
                {appName || 'KoshPay Finance'} · {sanitizedPkg} · v{version || '1.0.0'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-xl text-blue-100 hover:bg-white/10 hover:text-white transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method Selector Tabs */}
        <div className="px-5 pt-3.5 pb-2 border-b border-slate-200 bg-[#F4F7FB] flex flex-wrap gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setTab('pwabuilder')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              tab === 'pwabuilder'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '1. PWA-to-APK (सोपा मार्ग)' : '1. PWA-to-APK (No Coding)'}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('capacitor')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              tab === 'capacitor'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '2. Capacitor + Android Studio' : '2. Capacitor + Android Studio'}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('cloud')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors min-h-[40px] ${
              tab === 'cloud'
                ? 'bg-[#0070E0] text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>{lang === 'mr' ? '3. Cloud APK (GitHub)' : '3. Cloud APK (GitHub Actions)'}</span>
          </button>
        </div>

        {/* Scrollable Guide Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 leading-relaxed">
          {tab === 'pwabuilder' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-[#002E6E]">
                <p className="font-semibold">
                  {lang === 'mr'
                    ? 'या अ‍ॅपमध्ये PWA Manifest, Service Worker आणि PNG आयकॉन्स आधीच तयार आहेत.'
                    : 'This web app already includes a compliant Web App Manifest, offline Service Worker, and 192×192 / 512×512 Android PNG icons.'}
                </p>
                <p className="text-[11px] text-slate-600 mt-1">
                  {lang === 'mr'
                    ? 'Android Studio इन्स्टॉल न करता तुम्ही ऑनलाइन PWA-to-APK सेवेतून थेट .APK बनवू शकता.'
                    : 'You can convert your live URL into a signed Android APK online without installing Android Studio.'}
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 1 · {lang === 'mr' ? 'तुमची App URL कॉपी करा' : 'Copy Your Live App URL'}
                  </p>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 bg-[#F4F7FB] border border-slate-200 rounded-lg">
                    <span className="font-mono-num text-[11px] text-slate-800 break-all">
                      {appUrl}
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('url', appUrl)}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-lg shrink-0 min-h-[36px]"
                    >
                      {copiedKey === 'url' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === 'url' ? 'Copied' : 'Copy URL'}</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                  <p className="font-bold text-[#002E6E]">
                    Step 2 · {lang === 'mr' ? 'PWABuilder किंवा Web2APK सेवेवर पेस्ट करा' : 'Package Using PWABuilder (Free Online Tool)'}
                  </p>
                  <p>
                    1. Open <span className="font-mono-num font-semibold text-[#0070E0]">https://www.pwabuilder.com</span> in a browser tab.
                  </p>
                  <p>
                    2. Paste the copied App URL and click <strong>Start</strong>. PWABuilder will automatically detect your manifest and service worker.
                  </p>
                  <p>
                    3. Click <strong>Package for Stores → Android → Generate Package</strong>, enter Package ID <span className="font-mono-num font-semibold">{sanitizedPkg}</span>, and download the ZIP containing your signed <span className="font-mono-num">.apk</span> file.
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-[#F4F7FB] space-y-1.5">
                  <p className="font-bold text-[#002E6E]">
                    {lang === 'mr'
                      ? 'पर्याय: APK शिवाय थेट Android फोनवर Install करा'
                      : 'Alternative: Instant Install on Android (Zero APK Required)'}
                  </p>
                  <p>
                    {lang === 'mr'
                      ? 'Android फोनवरील Google Chrome मध्ये ही लिंक उघडा आणि वरच्या उजव्या बाजूच्या ⋮ (Menu) → Install app / Add to Home screen वर क्लिक करा.'
                      : 'Open the copied URL in Google Chrome on Android, tap ⋮ (Menu) → Install app / Add to Home screen. It installs with the KoshPay icon and runs offline in standalone app mode.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {tab === 'capacitor' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-[#002E6E]">
                <p className="font-semibold">
                  {lang === 'mr'
                    ? 'संपूर्ण Capacitor Android प्रोजेक्ट ZIP मधून स्थानिक (Offline) APK तयार करा'
                    : 'Compile a fully standalone offline APK locally using Capacitor & Android Studio'}
                </p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Prerequisites: Node.js 18+, JDK 17, and Android Studio (Android SDK 34).
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 1 · {lang === 'mr' ? 'Android APK प्रोजेक्ट ZIP डाउनलोड करा' : 'Download Pre-Configured Capacitor Project (.zip)'}
                  </p>
                  <button
                    type="button"
                    disabled={isExportingApk}
                    onClick={onDownloadZip}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] disabled:opacity-60 rounded-xl min-h-[38px]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isExportingApk ? 'Packaging...' : 'Download APK Project (.zip)'}</span>
                  </button>
                </div>
                <p className="text-slate-600">
                  Extract the downloaded ZIP into a folder on your computer. It already includes <span className="font-mono-num">capacitor.config.json</span>, <span className="font-mono-num">@capacitor/android</span> dependencies, PNG icons, and your complete React source code.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 2 · {lang === 'mr' ? 'टर्मिनलमध्ये खालील कमांड्स चालवा' : 'Build Web Assets & Sync Android Project'}
                  </p>
                  <button
                    type="button"
                    onClick={() => copyText('cap', capacitorCommands)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-lg"
                  >
                    {copiedKey === 'cap' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'cap' ? 'Copied' : 'Copy Commands'}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-900 text-slate-100 font-mono-num text-[11px] overflow-x-auto leading-relaxed">
{capacitorCommands}
                </pre>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-[#002E6E]">
                    Step 3 · {lang === 'mr' ? 'Android Studio किंवा Gradle मधून .APK बनवा' : 'Generate Debug or Signed Release APK'}
                  </p>
                  <button
                    type="button"
                    onClick={() => copyText('gradle', gradleCommand)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-lg"
                  >
                    {copiedKey === 'gradle' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'gradle' ? 'Copied' : 'Copy Gradle Cmd'}</span>
                  </button>
                </div>
                <p>
                  <strong>In Android Studio:</strong> Click <strong>Build → Build Bundle(s) / APK(s) → Build APK(s)</strong> (or <strong>Generate Signed Bundle / APK</strong> for Play Store/production distribution).
                </p>
                <p>
                  <strong>Via CLI:</strong> Run <span className="font-mono-num bg-slate-100 px-1.5 py-0.5 rounded">{gradleCommand}</span>. Your installable file will be saved at <span className="font-mono-num text-[#002E6E]">android/app/build/outputs/apk/debug/app-debug.apk</span>.
                </p>
              </div>
            </div>
          )}

          {tab === 'cloud' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 text-[#002E6E]">
                <p className="font-semibold">
                  {lang === 'mr'
                    ? 'Android Studio शिवाय GitHub Cloud वर आपोआप APK तयार करा'
                    : 'Compile an APK automatically in the cloud using GitHub Actions (No Android Studio required)'}
                </p>
                <p className="text-[11px] text-slate-600 mt-1">
                  The exported project ZIP already includes <span className="font-mono-num">.github/workflows/build-apk.yml</span> configured with JDK 17, Node 20, and Capacitor Android.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                <p className="font-bold text-[#002E6E]">1. Download &amp; Extract the APK Project ZIP</p>
                <p>
                  Use the <strong>Download APK Project (.zip)</strong> button so your current App Name (<span className="font-mono-num">{appName || 'KoshPay Finance'}</span>) and Package ID (<span className="font-mono-num">{sanitizedPkg}</span>) are baked into the workflow.
                </p>
                <button
                  type="button"
                  disabled={isExportingApk}
                  onClick={onDownloadZip}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] disabled:opacity-60 rounded-xl min-h-[38px]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isExportingApk ? 'Packaging...' : 'Download APK Project (.zip)'}</span>
                </button>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                <p className="font-bold text-[#002E6E]">2. Push to a GitHub Repository</p>
                <p>
                  Create a free repository on GitHub and upload/push the extracted project files (make sure the <span className="font-mono-num">.github/workflows/build-apk.yml</span> folder is included).
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                <p className="font-bold text-[#002E6E]">3. Download Compiled APK from Actions Artifacts</p>
                <p>
                  Open the <strong>Actions</strong> tab in your GitHub repository, select <strong>Build Android APK</strong> (or trigger <strong>Run workflow</strong>), wait ~2–3 minutes for Gradle to finish, and download the compiled <span className="font-mono-num">app-debug.apk</span> under <strong>Artifacts</strong>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-200 bg-white flex items-center justify-between gap-3 shrink-0">
          <span className="text-[11px] text-slate-500">
            {lang === 'mr'
              ? 'सर्व व्यवहार डेटा फोनवर ऑफलाइन सुरक्षित राहतो.'
              : 'All ledger data stays offline on device via localStorage.'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#002E6E] hover:bg-[#001F4D] rounded-xl min-h-[40px]"
          >
            {lang === 'mr' ? 'बंद करा' : 'Close Guide'}
          </button>
        </div>
      </div>
    </div>
  );
};
