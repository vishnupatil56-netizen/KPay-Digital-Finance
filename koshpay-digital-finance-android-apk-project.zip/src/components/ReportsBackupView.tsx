import React, { useMemo, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { exportToCSV, formatDateOnly, formatDateTime, formatINR, todayISO } from '../utils/formatters';
import { FieldLabel, SectionHeader, monoInputClass } from './FormControls';

type ReportCategory =
  | 'summary'
  | 'profit_loss'
  | 'pending'
  | 'bc'
  | 'luckydraw'
  | 'loans'
  | 'emi'
  | 'expenses';

type PeriodPreset = 'all' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';

export const ReportsBackupView: React.FC = () => {
  const { db, lang, summary, ledgerEntries } = useFinance();

  const [reportCat, setReportCat] = useState<ReportCategory>('summary');
  const [period, setPeriod] = useState<PeriodPreset>('all');
  const [fromDate, setFromDate] = useState(todayISO().slice(0, 8) + '01');
  const [toDate, setToDate] = useState(todayISO());

  const dateRange = useMemo(() => {
    const today = todayISO();
    if (period === 'daily') return { start: today, end: today };
    if (period === 'weekly') {
      const d = new Date(today + 'T00:00:00');
      d.setDate(d.getDate() - 6);
      return { start: d.toISOString().split('T')[0], end: today };
    }
    if (period === 'monthly') return { start: today.slice(0, 7) + '-01', end: today };
    if (period === 'yearly') return { start: today.slice(0, 4) + '-01-01', end: today };
    if (period === 'custom') return { start: fromDate, end: toDate };
    return { start: '1900-01-01', end: '2999-12-31' };
  }, [period, fromDate, toDate]);

  const filteredLedger = useMemo(
    () =>
      ledgerEntries.filter(
        (e) => e.date >= dateRange.start && e.date <= dateRange.end && e.status === 'Completed'
      ),
    [ledgerEntries, dateRange]
  );

  const periodTotals = useMemo(() => {
    let collection = 0;
    let payout = 0;
    let expense = 0;
    for (const e of filteredLedger) {
      if (e.direction === 'credit') collection += e.amount;
      else if (e.txnType === 'expense') expense += e.amount;
      else payout += e.amount;
    }
    return { collection, payout, expense, net: collection - payout - expense };
  }, [filteredLedger]);

  // Profit & Loss breakdown within period
  const pnlStats = useMemo(() => {
    const procFees = db.loans
      .filter((l) => l.loanDate >= dateRange.start && l.loanDate <= dateRange.end)
      .reduce((s, l) => s + l.processingFee, 0);
    const bcLateFees = db.bcCollections
      .filter((c) => c.collectionDate >= dateRange.start && c.collectionDate <= dateRange.end)
      .reduce((s, c) => s + c.lateFee, 0);
    const ldLateFees = db.luckyDrawCollections
      .filter((c) => c.collectionDate >= dateRange.start && c.collectionDate <= dateRange.end)
      .reduce((s, c) => s + c.lateFee, 0);
    const emiLateFees = db.emiPayments
      .filter((p) => p.paymentDate >= dateRange.start && p.paymentDate <= dateRange.end)
      .reduce((s, p) => s + p.lateFee, 0);
    const interestEarned = db.emiSchedules
      .filter((s) => s.status === 'Paid' && s.paidDate && s.paidDate >= dateRange.start && s.paidDate <= dateRange.end)
      .reduce((s, r) => s + r.interestComponent, 0);
    const expenses = db.expenses
      .filter((e) => e.expenseDate >= dateRange.start && e.expenseDate <= dateRange.end)
      .reduce((s, e) => s + e.amount, 0);

    const totalRevenue = procFees + bcLateFees + ldLateFees + emiLateFees + interestEarned;
    return {
      procFees,
      lateFees: bcLateFees + ldLateFees + emiLateFees,
      interestEarned,
      totalRevenue,
      expenses,
      netProfit: totalRevenue - expenses,
    };
  }, [db, dateRange]);

  const overdueSchedules = useMemo(() => {
    const today = todayISO();
    return db.emiSchedules.filter((s) => s.status !== 'Paid' && s.dueDate <= today);
  }, [db.emiSchedules]);

  const categories: { id: ReportCategory; label: string }[] = [
    { id: 'summary', label: 'Collection & Cashflow' },
    { id: 'profit_loss', label: 'Profit & Loss' },
    { id: 'pending', label: 'Pending & Overdue' },
    { id: 'bc', label: 'BC Reports' },
    { id: 'luckydraw', label: 'Lucky Draw Reports' },
    { id: 'loans', label: 'Loan Reports' },
    { id: 'emi', label: 'EMI Collection' },
    { id: 'expenses', label: 'Expense Reports' },
  ];

  const handleExportCurrentReport = () => {
    if (reportCat === 'loans') {
      exportToCSV(
        'loan_report',
        ['Loan ID', 'Customer', 'Mobile', 'Type', 'Principal', 'Rate %', 'EMI', 'Principal Out', 'Status'],
        db.loans.map((l) => [
          l.id,
          l.customerName,
          l.mobile,
          l.loanType,
          l.loanAmount,
          l.interestRate,
          l.emiAmount,
          l.principalOutstanding,
          l.loanStatus,
        ])
      );
      return;
    }
    if (reportCat === 'emi') {
      exportToCSV(
        'emi_collection_report',
        ['Receipt #', 'Loan ID', 'Customer', 'EMI #', 'Date', 'Amount Paid', 'Late Fee', 'Mode'],
        db.emiPayments.map((p) => [
          p.receiptNumber,
          p.loanId,
          p.customerName,
          p.installmentNumber,
          p.paymentDate,
          p.amountPaid,
          p.lateFee,
          p.paymentMode,
        ])
      );
      return;
    }
    if (reportCat === 'expenses') {
      exportToCSV(
        'expense_report',
        ['ID', 'Date', 'Category', 'Description', 'Mode', 'Amount'],
        db.expenses.map((e) => [e.id, e.expenseDate, e.category, e.description, e.paymentMode, e.amount])
      );
      return;
    }
    exportToCSV(
      `report_${reportCat}`,
      ['Ref #', 'Date', 'Timestamp', 'Party / Group', 'Description', 'Mode', 'Book', 'Direction', 'Amount'],
      filteredLedger.map((e) => [
        e.referenceNumber,
        e.date,
        formatDateTime(e.timestamp),
        e.memberName || e.groupName || '',
        e.description,
        e.paymentMode,
        e.book,
        e.direction,
        e.amount,
      ])
    );
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'रिपोर्ट्स व नफा-तोटा विश्लेषण' : 'Reports & Financial Analytics'}
        subtitle={
          lang === 'mr'
            ? 'दैनिक, साप्ताहिक, मासिक, वार्षिक रिपोर्ट्स, नफा-तोटा, प्रलंबित हप्ते आणि Excel / PDF एक्सपोर्ट'
            : 'Daily, Weekly, Monthly & Yearly reports, Profit & Loss, Pending EMIs, and PDF / Excel export'
        }
        actions={
          <div className="flex items-center gap-2 no-print">
            <button
              type="button"
              onClick={handleExportCurrentReport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Excel (CSV)</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
          </div>
        }
      />

      {/* Period & Date Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 no-print">
        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'all', label: 'All Time' },
              { id: 'daily', label: 'Daily (Today)' },
              { id: 'weekly', label: 'Weekly (7 Days)' },
              { id: 'monthly', label: 'Monthly' },
              { id: 'yearly', label: 'Yearly' },
              { id: 'custom', label: 'Custom Dates' },
            ] as const
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                period === p.id
                  ? 'bg-[#002E6E] text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {period === 'custom' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 max-w-md">
            <div>
              <FieldLabel label="From Date" />
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
            <div>
              <FieldLabel label="To Date" />
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className={monoInputClass}
              />
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setReportCat(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                reportCat === cat.id
                  ? 'border-[#0070E0] bg-blue-50 text-[#002E6E]'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Period Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Collection</p>
          <p className="text-lg font-bold text-emerald-700 font-mono-num mt-1">
            {formatINR(periodTotals.collection)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Payout / Loans</p>
          <p className="text-lg font-bold text-slate-900 font-mono-num mt-1">
            {formatINR(periodTotals.payout)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Period Expenses</p>
          <p className="text-lg font-bold text-red-600 font-mono-num mt-1">
            {formatINR(periodTotals.expense)}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs text-slate-500">Net Period Cashflow</p>
          <p className="text-lg font-bold text-[#002E6E] font-mono-num mt-1">
            {formatINR(periodTotals.net)}
          </p>
        </div>
      </div>

      {/* PROFIT & LOSS VIEW */}
      {reportCat === 'profit_loss' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 print-container max-w-2xl">
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Profit &amp; Loss Statement ({period === 'all' ? 'All Time' : `${dateRange.start} to ${dateRange.end}`})
          </h3>
          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Loan Interest Earned</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.interestEarned)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Loan Processing Fees</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.procFees)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Late Fees (BC + Lucky Draw + EMI)</span>
              <span className="font-mono-num font-semibold text-emerald-700">
                + {formatINR(pnlStats.lateFees)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Operating Expenses</span>
              <span className="font-mono-num font-semibold text-red-600">
                - {formatINR(pnlStats.expenses)}
              </span>
            </div>
            <div className="flex justify-between pt-3 border-t border-slate-900 text-sm font-bold">
              <span className="text-[#002E6E]">Net Operating Profit / (Loss)</span>
              <span
                className={`font-mono-num ${
                  pnlStats.netProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {formatINR(pnlStats.netProfit)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* PENDING & OVERDUE VIEW */}
      {reportCat === 'pending' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#002E6E]">
              Due &amp; Overdue Loan EMIs ({overdueSchedules.length})
            </h3>
            <span className="text-xs font-mono-num font-semibold text-amber-700">
              Total Due: {formatINR(summary.pendingEMI)}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Loan ID</th>
                  <th className="py-2.5 px-4">Customer</th>
                  <th className="py-2.5 px-4">EMI #</th>
                  <th className="py-2.5 px-4">Due Date</th>
                  <th className="py-2.5 px-4 text-right">Due Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {overdueSchedules.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-emerald-700 font-medium">
                      No overdue EMIs as of today.
                    </td>
                  </tr>
                ) : (
                  overdueSchedules.map((s) => {
                    const loan = db.loans.find((l) => l.id === s.loanId);
                    return (
                      <tr key={s.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num font-medium">{s.loanId}</td>
                        <td className="py-3 px-4 font-medium">{loan?.customerName ?? s.loanId}</td>
                        <td className="py-3 px-4 font-mono-num">EMI #{s.installmentNumber}</td>
                        <td className="py-3 px-4 font-mono-num text-red-600">
                          {formatDateOnly(s.dueDate)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold">
                          {formatINR(Math.max(0, s.emiAmount - s.paidAmount))}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* FILTERED TRANSACTIONS TABLE FOR SUMMARY / BC / LD / LOANS / EMI / EXPENSES */}
      {reportCat !== 'profit_loss' && reportCat !== 'pending' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#002E6E]">
              {categories.find((c) => c.id === reportCat)?.label}
            </h3>
            <span className="text-xs font-mono-num text-slate-500">
              {dateRange.start === '1900-01-01' ? 'All Dates' : `${dateRange.start} → ${dateRange.end}`}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Ref #</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Party / Group</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Mode</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLedger
                  .filter((e) => {
                    if (reportCat === 'bc') return e.groupKind === 'bc';
                    if (reportCat === 'luckydraw') return e.groupKind === 'luckydraw';
                    if (reportCat === 'loans') return e.groupKind === 'loan';
                    if (reportCat === 'emi') return e.txnType === 'loan_emi';
                    if (reportCat === 'expenses') return e.txnType === 'expense';
                    return true;
                  })
                  .map((e) => (
                    <tr key={`${e.id}-${e.referenceNumber}`} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono-num font-medium">{e.referenceNumber}</td>
                      <td className="py-3 px-4 font-mono-num">{formatDateOnly(e.date)}</td>
                      <td className="py-3 px-4 font-medium">{e.memberName || e.groupName}</td>
                      <td className="py-3 px-4 text-slate-600">{e.description}</td>
                      <td className="py-3 px-4">{e.paymentMode}</td>
                      <td
                        className={`py-3 px-4 text-right font-mono-num font-semibold ${
                          e.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                        }`}
                      >
                        {e.direction === 'credit' ? '+' : '-'} {formatINR(e.amount)}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
