import React, { useMemo, useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  BookOpen,
  CreditCard,
  Gift,
  Layers,
  PieChart,
  Receipt,
  ReceiptText,
  Search,
  Users,
  Wallet,
} from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { translations } from '../i18n/translations';
import { formatDateOnly, formatDateTime, formatINR } from '../utils/formatters';
import { LedgerEntry, ReceiptData } from '../types/finance';
import { EmptyState, inputBaseClass } from './FormControls';

export const DashboardView: React.FC<{
  onNavigate: (tab: string) => void;
}> = ({ onNavigate }) => {
  const { db, lang, summary, ledgerEntries, setActiveReceipt } = useFinance();
  const t = translations[lang];
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'credit' | 'debit'>('all');

  const filteredEntries = useMemo(() => {
    const q = search.trim().toLowerCase();
    return ledgerEntries.filter((entry) => {
      if (typeFilter !== 'all' && entry.direction !== typeFilter) return false;
      if (!q) return true;
      return (
        entry.referenceNumber.toLowerCase().includes(q) ||
        (entry.memberName ?? '').toLowerCase().includes(q) ||
        (entry.groupName ?? '').toLowerCase().includes(q) ||
        entry.description.toLowerCase().includes(q)
      );
    });
  }, [ledgerEntries, search, typeFilter]);

  const openReceiptFromEntry = (entry: LedgerEntry) => {
    const saved = db.receipts.find((r) => r.receiptNumber === entry.referenceNumber);
    if (saved) {
      setActiveReceipt(saved);
      return;
    }
    const receipt: ReceiptData = {
      receiptNumber: entry.referenceNumber,
      title: entry.direction === 'credit' ? 'Payment Receipt' : 'Payment Voucher',
      date: entry.date,
      timestamp: entry.timestamp,
      partyName: entry.memberName || entry.groupName || 'Account Party',
      partyId: entry.memberId,
      groupName: entry.groupName,
      paymentType: entry.txnType,
      installmentOrDraw: entry.description,
      breakdown: [{ label: entry.description, value: entry.amount }],
      totalAmount: entry.amount,
      paymentMode: entry.paymentMode,
      status: entry.status,
    };
    setActiveReceipt(receipt);
  };

  const quickServices = [
    { id: 'bc', label: t.navBC, icon: Layers, bg: 'bg-blue-50 text-[#0070E0]' },
    { id: 'luckydraw', label: t.navLuckyDraw, icon: Gift, bg: 'bg-sky-50 text-sky-700' },
    { id: 'members', label: t.navMembers, icon: Users, bg: 'bg-indigo-50 text-indigo-700' },
    { id: 'loans', label: t.navLoans, icon: CreditCard, bg: 'bg-emerald-50 text-emerald-700' },
    { id: 'universal', label: t.quickEntry, icon: Wallet, bg: 'bg-blue-50 text-[#002E6E]' },
    { id: 'cashbank', label: t.navCashBank, icon: BookOpen, bg: 'bg-cyan-50 text-cyan-700' },
    { id: 'expenses', label: t.navExpenses, icon: Receipt, bg: 'bg-amber-50 text-amber-700' },
    { id: 'reports', label: t.navReports, icon: PieChart, bg: 'bg-slate-100 text-slate-700' },
  ];

  return (
    <div className="space-y-6">
      {/* Paytm-Inspired Blue & White Banking Hero Balance Card */}
      <div className="bg-gradient-to-br from-[#002E6E] to-[#0055B8] text-white rounded-2xl p-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="space-y-1.5">
          <p className="text-xs font-medium text-blue-100">
            {db.settings.businessName} · {t.totalAvailableBalance}
          </p>
          <p className="text-3xl sm:text-4xl font-bold font-mono-num tracking-tight">
            {formatINR(summary.totalAvailableBalance)}
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-blue-100">
            <span>
              {t.cashInHand}: <strong className="font-mono-num text-white">{formatINR(summary.cashBalance)}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              {t.bankBalance}: <strong className="font-mono-num text-white">{formatINR(summary.bankBalance)}</strong>
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 no-print">
          <button
            type="button"
            onClick={() => onNavigate('universal')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#002E6E] bg-white hover:bg-blue-50 rounded-xl transition-colors whitespace-nowrap"
          >
            <Banknote className="w-4 h-4 text-[#0070E0]" />
            <span>{t.quickEntry}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('loans')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-white/15 hover:bg-white/25 rounded-xl transition-colors whitespace-nowrap"
          >
            <CreditCard className="w-4 h-4" />
            <span>{t.navLoans}</span>
          </button>
        </div>
      </div>

      {/* Quick Access Services (Paytm-style Rounded Service Icons) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 no-print">
        <h2 className="text-sm font-bold text-[#002E6E] font-display mb-4">
          {lang === 'mr' ? 'जलद सेवा (Quick Access)' : 'Financial Services'}
        </h2>
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
          {quickServices.map((svc) => {
            const Icon = svc.icon;
            return (
              <button
                key={svc.id}
                type="button"
                onClick={() => onNavigate(svc.id)}
                className="flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-slate-50 transition-colors group"
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${svc.bg}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-medium text-slate-700 text-center leading-tight line-clamp-2">
                  {svc.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* All 8 Required Financial KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalAvailableBalance}</p>
          <p className="text-lg sm:text-xl font-bold text-[#002E6E] font-mono-num mt-1.5">
            {formatINR(summary.totalAvailableBalance)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalCollection}</p>
          <p className="text-lg sm:text-xl font-bold text-emerald-700 font-mono-num mt-1.5">
            {formatINR(summary.totalCollection)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalLoanOutstanding}</p>
          <p className="text-lg sm:text-xl font-bold text-[#0070E0] font-mono-num mt-1.5">
            {formatINR(summary.totalLoanOutstanding)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalBCCollection}</p>
          <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono-num mt-1.5">
            {formatINR(summary.totalBCCollection)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalLDCollection}</p>
          <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono-num mt-1.5">
            {formatINR(summary.totalLDCollection)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.totalExpenses}</p>
          <p className="text-lg sm:text-xl font-bold text-red-600 font-mono-num mt-1.5">
            {formatINR(summary.totalExpenses)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.pendingEMI}</p>
          <p className="text-lg sm:text-xl font-bold text-amber-700 font-mono-num mt-1.5">
            {formatINR(summary.pendingEMI)}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500">{t.pendingMemberPayments}</p>
          <p className="text-lg sm:text-xl font-bold text-amber-700 font-mono-num mt-1.5">
            {formatINR(summary.pendingMemberPayments)}
          </p>
        </div>
      </div>

      {/* Transaction History */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 px-5 py-4 border-b border-slate-200">
          <div>
            <h2 className="text-sm font-bold text-[#002E6E] font-display">{t.recentTransactions}</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {filteredEntries.length} verified ledger entries
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
            <div className="relative min-w-[210px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t.searchPlaceholder}
                className={`${inputBaseClass} pl-9 min-h-[38px] text-xs`}
              />
            </div>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
              {(['all', 'credit', 'debit'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setTypeFilter(f)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    typeFilter === f
                      ? 'bg-white text-[#002E6E] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {f === 'all' ? 'All' : f === 'credit' ? 'Credit (+)' : 'Debit (-)'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredEntries.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No matching transactions"
              description="Adjust your search filter or record a new payment."
              actionLabel={t.quickEntry}
              onAction={() => onNavigate('universal')}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">Ref #</th>
                  <th className="py-2.5 px-4">Date &amp; Time</th>
                  <th className="py-2.5 px-4">Party / Account</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Mode / Book</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                  <th className="py-2.5 px-4 text-right no-print">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredEntries.slice(0, 20).map((entry) => (
                  <tr key={`${entry.id}-${entry.referenceNumber}`} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-num font-medium text-slate-700 whitespace-nowrap">
                      {entry.referenceNumber}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="text-slate-900 font-mono-num">{formatDateOnly(entry.date)}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        {formatDateTime(entry.timestamp)}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">
                        {entry.memberName || entry.groupName || '-'}
                      </div>
                      {entry.memberName && entry.groupName && (
                        <div className="text-[11px] text-slate-500">{entry.groupName}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{entry.description}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="text-slate-700">{entry.paymentMode}</span>
                      <span className="text-slate-400 mx-1">·</span>
                      <span className="text-slate-500">{entry.book}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 ${
                          entry.direction === 'credit' ? 'text-emerald-700' : 'text-red-600'
                        }`}
                      >
                        {entry.direction === 'credit' ? (
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                        ) : (
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        )}
                        {entry.direction === 'credit' ? '+' : '-'} {formatINR(entry.amount)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right no-print">
                      <button
                        type="button"
                        onClick={() => openReceiptFromEntry(entry)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#0070E0] hover:bg-blue-50 rounded-lg transition-colors whitespace-nowrap"
                      >
                        <ReceiptText className="w-3.5 h-3.5" />
                        <span>View</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
