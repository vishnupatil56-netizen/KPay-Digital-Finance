import React, { useMemo, useState } from 'react';
import { Download } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { ExpenseCategory, PaymentMode } from '../types/finance';
import { exportToCSV, formatDateOnly, formatINR, generateNextId, todayISO } from '../utils/formatters';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

const CATEGORIES: ExpenseCategory[] = [
  'Office Rent',
  'Printing & Stationery',
  'Meeting & Refreshments',
  'Staff Salary',
  'Draw Event',
  'Travel',
  'Bank Charges',
  'Other',
];

export const ExpenseManagementView: React.FC = () => {
  const { db, lang, addExpense } = useFinance();

  const [category, setCategory] = useState<ExpenseCategory>('Printing & Stationery');
  const [linkedKind, setLinkedKind] = useState<'general' | 'bc' | 'luckydraw' | 'loan'>('general');
  const [linkedGroupId, setLinkedGroupId] = useState('');
  const [expenseDate, setExpenseDate] = useState(todayISO());
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState(0);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('Cash');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [remarks, setRemarks] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  const nextExpenseId = useMemo(
    () => generateNextId('EXP', db.expenses.map((e) => e.id), 4),
    [db.expenses]
  );

  const totalExpenses = useMemo(
    () => db.expenses.reduce((sum, e) => sum + e.amount, 0),
    [db.expenses]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const res = addExpense({
      category,
      linkedKind,
      linkedGroupId: linkedKind === 'general' ? undefined : linkedGroupId,
      expenseDate,
      description,
      amount,
      paymentMode,
      referenceNumber,
      remarks,
    });
    if (res.ok) {
      setFeedback({
        type: 'success',
        message: `Expense ${res.id} recorded & deducted from ${paymentMode === 'Cash' ? 'Cash Book' : 'Bank Book'}.`,
      });
      setDescription('');
      setAmount(0);
      setReferenceNumber('');
      setRemarks('');
    } else {
      setFeedback({ type: 'error', message: res.error ?? 'Failed to record expense.' });
    }
  };

  const getLinkedName = (kind: 'general' | 'bc' | 'luckydraw' | 'loan', groupId?: string) => {
    if (kind === 'general') return 'General Office';
    if (kind === 'bc') return db.bcGroups.find((g) => g.id === groupId)?.name ?? groupId ?? 'BC';
    if (kind === 'loan') {
      const loan = db.loans.find((l) => l.id === groupId);
      return loan ? `${loan.customerName} (${loan.id})` : groupId ?? 'Loan';
    }
    return db.luckyDrawGroups.find((g) => g.id === groupId)?.name ?? groupId ?? 'Lucky Draw';
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        title={lang === 'mr' ? 'खर्च व्यवस्थापन (Expense Form)' : 'Expense Management'}
        subtitle={
          lang === 'mr'
            ? 'ऑफिस, छपाई, मीटिंग किंवा विशिष्ट BC / लकी ड्रॉ खर्चाची नोंद व कॅश/बँक बुक अपडेट'
            : 'Record general or group-specific expenses with automatic Cash/Bank Book deduction'
        }
        actions={
          <button
            type="button"
            onClick={() =>
              exportToCSV(
                'expenses_register',
                ['Expense ID', 'Date', 'Category', 'Linked Account', 'Description', 'Mode', 'Ref #', 'Amount'],
                db.expenses.map((e) => [
                  e.id,
                  e.expenseDate,
                  e.category,
                  getLinkedName(e.linkedKind, e.linkedGroupId),
                  e.description,
                  e.paymentMode,
                  e.referenceNumber,
                  e.amount,
                ])
              )
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Expenses CSV</span>
          </button>
        }
      />

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Expense Entry Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 space-y-4 self-start"
        >
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Expense Management Form
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <FieldLabel label="Expense ID (Auto)" />
              <input type="text" readOnly value={nextExpenseId} className={monoInputClass} />
            </div>

            <div>
              <FieldLabel label="Expense Date" required />
              <input
                type="date"
                required
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                className={monoInputClass}
              />
            </div>

            <div className="sm:col-span-2">
              <FieldLabel label="Expense Category" required />
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className={inputBaseClass}
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <FieldLabel label="BC / Lucky Draw / Loan Selection" required />
              <select
                value={linkedKind}
                onChange={(e) => {
                  const next = e.target.value as 'general' | 'bc' | 'luckydraw' | 'loan';
                  setLinkedKind(next);
                  setLinkedGroupId(
                    next === 'bc'
                      ? db.bcGroups.find((g) => !g.isDeleted)?.id ?? ''
                      : next === 'luckydraw'
                        ? db.luckyDrawGroups[0]?.id ?? ''
                        : next === 'loan'
                          ? db.loans[0]?.id ?? ''
                          : ''
                  );
                }}
                className={inputBaseClass}
              >
                <option value="general">General Office Expense</option>
                <option value="bc">BC Group Expense</option>
                <option value="luckydraw">Lucky Draw Expense</option>
                <option value="loan">Loan Account Expense</option>
              </select>
            </div>

            {linkedKind !== 'general' && (
              <div className="sm:col-span-2">
                <FieldLabel
                  label={
                    linkedKind === 'bc'
                      ? 'Select BC Group'
                      : linkedKind === 'loan'
                        ? 'Select Loan Account'
                        : 'Select Lucky Draw'
                  }
                  required
                />
                <select
                  value={linkedGroupId}
                  onChange={(e) => setLinkedGroupId(e.target.value)}
                  className={inputBaseClass}
                >
                  {linkedKind === 'bc' &&
                    db.bcGroups
                      .filter((g) => !g.isDeleted)
                      .map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name} ({g.id})
                        </option>
                      ))}
                  {linkedKind === 'luckydraw' &&
                    db.luckyDrawGroups.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.name} ({g.id})
                      </option>
                    ))}
                  {linkedKind === 'loan' &&
                    db.loans.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.customerName} ({l.id})
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div className="sm:col-span-2">
              <FieldLabel label="Expense Description" required />
              <input
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Details of expense"
                className={inputBaseClass}
              />
            </div>

            <div>
              <FieldLabel label="Expense Amount (₹)" required />
              <input
                type="number"
                min={1}
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className={monoInputClass}
              />
            </div>

            <div>
              <FieldLabel label="Payment Mode" required />
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                className={inputBaseClass}
              >
                <option value="Cash">Cash</option>
                <option value="UPI">UPI</option>
                <option value="Bank">Bank</option>
              </select>
            </div>

            <div>
              <FieldLabel label="Receipt / Ref Number" />
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="Bill # or Ref"
                className={monoInputClass}
              />
            </div>

            <div>
              <FieldLabel label="Remarks" />
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Optional note"
                className={inputBaseClass}
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl transition-colors"
          >
            Save Expense
          </button>
        </form>

        {/* Expense Register Table */}
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Expense Register</h3>
              <p className="text-xs text-slate-500">{db.expenses.length} entries</p>
            </div>
            <div className="text-right">
              <p className="text-[11px] text-slate-500">Total Expenses</p>
              <p className="text-base font-bold text-red-600 font-mono-num">
                {formatINR(totalExpenses)}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500">
                  <th className="py-2.5 px-4">ID</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Category &amp; Account</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Mode</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {db.expenses.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No expenses recorded yet.
                    </td>
                  </tr>
                ) : (
                  [...db.expenses].reverse().map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono-num font-medium">{exp.id}</td>
                      <td className="py-3 px-4 font-mono-num whitespace-nowrap">
                        {formatDateOnly(exp.expenseDate)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{exp.category}</div>
                        <div className="text-[11px] text-slate-500">
                          {getLinkedName(exp.linkedKind, exp.linkedGroupId)}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{exp.description}</td>
                      <td className="py-3 px-4">{exp.paymentMode}</td>
                      <td className="py-3 px-4 text-right font-mono-num font-semibold text-red-600">
                        - {formatINR(exp.amount)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
