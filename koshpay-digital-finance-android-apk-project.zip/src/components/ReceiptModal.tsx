import React, { useState } from 'react';
import { Copy, Check, Printer, X, Share2 } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatDateOnly, formatDateTime, formatINR } from '../utils/formatters';

export const ReceiptModal: React.FC = () => {
  const { activeReceipt, setActiveReceipt, db, lang } = useFinance();
  const [copied, setCopied] = useState(false);

  if (!activeReceipt) return null;

  const businessName = activeReceipt.businessName || db.settings.businessName;
  const signatory = activeReceipt.authorizedSignature || db.settings.authorizedSignatory;

  const buildShareText = () =>
    [
      `*${businessName}*`,
      `${activeReceipt.title}`,
      `Receipt #: ${activeReceipt.receiptNumber}`,
      `Date: ${formatDateOnly(activeReceipt.date)}`,
      `Name: ${activeReceipt.partyName}${activeReceipt.partyId ? ` (${activeReceipt.partyId})` : ''}`,
      activeReceipt.paymentType ? `Type: ${activeReceipt.paymentType}` : '',
      activeReceipt.groupName ? `Account: ${activeReceipt.groupName}` : '',
      activeReceipt.installmentOrDraw ? `Ref: ${activeReceipt.installmentOrDraw}` : '',
      `*Amount: ${formatINR(activeReceipt.totalAmount)}*`,
      `Mode: ${activeReceipt.paymentMode}`,
      activeReceipt.remainingBalance !== undefined
        ? `Remaining Balance: ${formatINR(activeReceipt.remainingBalance)}`
        : '',
      `Status: ${activeReceipt.status}`,
    ]
      .filter(Boolean)
      .join('\n');

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const encoded = encodeURIComponent(buildShareText());
    window.open(`https://wa.me/?text=${encoded}`, '_blank', 'noopener,noreferrer');
  };

  const handleCopySummary = async () => {
    try {
      await navigator.clipboard.writeText(buildShareText());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-label="Official Payment Receipt"
    >
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl overflow-hidden print-container">
        {/* Top Modal Controls */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#002E6E] text-white no-print">
          <span className="text-xs font-semibold">
            {lang === 'mr' ? 'अधिकृत पावती / व्हाउचर' : 'Official Payment Receipt'}
          </span>
          <button
            type="button"
            onClick={() => setActiveReceipt(null)}
            className="p-1.5 text-blue-100 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Close receipt"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Printable Receipt Body */}
        <div className="p-6 space-y-4">
          <div className="text-center pb-4 border-b border-dashed border-slate-300">
            <p className="text-xs font-bold text-[#0070E0] uppercase tracking-wide">
              {businessName}
            </p>
            <h3 className="text-base font-bold text-[#002E6E] mt-1 font-display">
              {activeReceipt.title}
            </h3>
            <div className="flex items-center justify-center gap-2 text-xs text-slate-500 mt-1.5 font-mono-num">
              <span>{activeReceipt.receiptNumber}</span>
              <span aria-hidden="true">·</span>
              <span>{formatDateTime(activeReceipt.timestamp)}</span>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between gap-4">
              <span className="text-slate-500">{lang === 'mr' ? 'सभासद / नाव' : 'Member / Party'}</span>
              <span className="font-semibold text-slate-900 text-right">
                {activeReceipt.partyName}
                {activeReceipt.partyId && (
                  <span className="text-slate-500 font-mono-num ml-1.5">({activeReceipt.partyId})</span>
                )}
              </span>
            </div>

            {activeReceipt.paymentType && (
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-500">{lang === 'mr' ? 'प्रकार' : 'Payment Type'}</span>
                <span className="font-medium text-slate-800">{activeReceipt.paymentType}</span>
              </div>
            )}

            {activeReceipt.groupName && (
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-500">{lang === 'mr' ? 'ग्रुप / खाते' : 'Account / Group'}</span>
                <span className="font-medium text-slate-800 text-right">{activeReceipt.groupName}</span>
              </div>
            )}

            {activeReceipt.installmentOrDraw && (
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-500">{lang === 'mr' ? 'तपशील' : 'Reference'}</span>
                <span className="font-medium text-slate-800 text-right font-mono-num">
                  {activeReceipt.installmentOrDraw}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between gap-4">
              <span className="text-slate-500">{lang === 'mr' ? 'पेमेंट तारीख' : 'Payment Date'}</span>
              <span className="font-medium text-slate-800 font-mono-num">
                {formatDateOnly(activeReceipt.date)}
              </span>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-slate-500">{lang === 'mr' ? 'पेमेंट पद्धत' : 'Payment Mode'}</span>
              <span className="font-medium text-slate-800">{activeReceipt.paymentMode}</span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200 space-y-2">
            {activeReceipt.breakdown.map((row, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <span className="text-slate-600">{row.label}</span>
                <span
                  className={`font-mono-num font-medium ${
                    row.isDeduction ? 'text-red-600' : 'text-slate-800'
                  }`}
                >
                  {row.isDeduction ? `- ${formatINR(row.value)}` : formatINR(row.value)}
                </span>
              </div>
            ))}

            <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-900">
              <span className="text-sm font-semibold text-slate-900">
                {lang === 'mr' ? 'एकूण रक्कम' : 'Amount Received / Paid'}
              </span>
              <span className="text-lg font-bold text-[#002E6E] font-mono-num">
                {formatINR(activeReceipt.totalAmount)}
              </span>
            </div>

            {activeReceipt.remainingBalance !== undefined && (
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-slate-500">
                  {lang === 'mr' ? 'शिल्लक बाकी' : 'Remaining Balance'}
                </span>
                <span className="font-mono-num font-semibold text-amber-700">
                  {formatINR(activeReceipt.remainingBalance)}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between text-xs pt-2 text-slate-600">
            <span>{lang === 'mr' ? 'स्थिती' : 'Status'}</span>
            <span className="font-semibold text-emerald-700">{activeReceipt.status}</span>
          </div>

          {activeReceipt.remarks && (
            <div className="text-xs text-slate-500 pt-2 border-t border-slate-100">
              <span className="font-medium text-slate-700">Remarks: </span>
              {activeReceipt.remarks}
            </div>
          )}

          {/* Authorized Signature Footer */}
          <div className="pt-5 mt-3 border-t border-dashed border-slate-200 flex items-end justify-between text-[11px] text-slate-500">
            <span>Computer-generated receipt</span>
            <div className="text-right">
              <div className="font-semibold text-slate-800">{signatory}</div>
              <div>Authorized Signature</div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-3.5 bg-slate-50 border-t border-slate-200 no-print">
          <button
            type="button"
            onClick={handleCopySummary}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors whitespace-nowrap"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl hover:bg-emerald-100 transition-colors whitespace-nowrap"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#0070E0] rounded-xl hover:bg-[#005BB5] transition-colors whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PDF / Print</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
