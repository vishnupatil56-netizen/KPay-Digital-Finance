import React, { useRef, useState } from 'react';
import { BookOpen, Copy, Download, Lock, RotateCcw, Shield, Smartphone, Trash2, Upload, Languages } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatDateTime } from '../utils/formatters';
import { downloadAndroidApkProjectZip } from '../utils/apkProjectExporter';
import { ApkInstructionsModal } from './ApkInstructionsModal';
import { PWAInstallButton } from './PWAInstallButton';
import { FieldLabel, FormAlert, SectionHeader, inputBaseClass, monoInputClass } from './FormControls';

export const SettingsView: React.FC = () => {
  const {
    db,
    lang,
    setLang,
    updateSettings,
    lockApp,
    exportBackupJSON,
    restoreBackupJSON,
    resetDatabase,
  } = useFinance();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [businessName, setBusinessName] = useState(db.settings.businessName);
  const [signatory, setSignatory] = useState(db.settings.authorizedSignatory);
  const [pinEnabled, setPinEnabled] = useState(db.settings.pinEnabled);
  const [appPin, setAppPin] = useState(db.settings.appPin);
  const [biometricEnabled, setBiometricEnabled] = useState(db.settings.biometricEnabled);
  const [confirmClear, setConfirmClear] = useState(false);
  const [apkAppName, setApkAppName] = useState(db.settings.businessName || 'KoshPay Finance');
  const [apkPackageId, setApkPackageId] = useState('com.koshpay.finance');
  const [apkVersion, setApkVersion] = useState('1.0.0');
  const [isExportingApk, setIsExportingApk] = useState(false);
  const [showApkGuide, setShowApkGuide] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; message: string } | null>(null);

  const handleSaveProfileAndSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinEnabled && !/^\d{4}$/.test(appPin)) {
      setFeedback({ type: 'error', message: 'App PIN must be exactly 4 digits.' });
      return;
    }
    updateSettings({
      businessName: businessName.trim() || 'KoshPay Digital Finance',
      authorizedSignatory: signatory.trim() || 'Authorized Signatory',
      pinEnabled,
      appPin,
      biometricEnabled,
    });
    setFeedback({ type: 'success', message: 'Business profile & security settings saved.' });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result ?? '');
      const res = restoreBackupJSON(content);
      setFeedback(
        res.ok
          ? { type: 'success', message: 'Database restored successfully from backup.' }
          : { type: 'error', message: res.error ?? 'Restore failed.' }
      );
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <SectionHeader
        title={lang === 'mr' ? 'सेटिंग्ज, सुरक्षा व बॅकअप' : 'Settings, Security & Backup'}
        subtitle={
          lang === 'mr'
            ? 'व्यवसायाचे नाव, App PIN सुरक्षा, ऑटो/मॅन्युअल बॅकअप, रिस्टोअर आणि ऑडिट हिस्ट्री'
            : 'Configure business profile, 4-digit App PIN lock, JSON database backup/restore, and view audit logs'
        }
      />

      {feedback && (
        <FormAlert
          type={feedback.type}
          message={feedback.message}
          onDismiss={() => setFeedback(null)}
        />
      )}

      {/* Business & Security Form */}
      <form
        onSubmit={handleSaveProfileAndSecurity}
        className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Business Profile &amp; App PIN Security
          </h3>
          <button
            type="button"
            onClick={() => setLang(lang === 'en' ? 'mr' : 'en')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#0070E0] bg-blue-50 hover:bg-blue-100 rounded-xl"
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Switch to मराठी' : 'Switch to English'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <FieldLabel label="Business Name (Shown on Receipts)" required />
            <input
              type="text"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className={inputBaseClass}
            />
          </div>

          <div>
            <FieldLabel label="Authorized Signatory Name" required />
            <input
              type="text"
              required
              value={signatory}
              onChange={(e) => setSignatory(e.target.value)}
              className={inputBaseClass}
            />
          </div>

          <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-[#F4F7FB] border border-slate-200 rounded-xl">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-[#0070E0] mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-slate-900">App PIN Protection</p>
                <p className="text-xs text-slate-500">
                  Require a 4-digit PIN when opening or locking the application.
                </p>
              </div>
            </div>
            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={pinEnabled}
                onChange={(e) => setPinEnabled(e.target.checked)}
                className="w-4 h-4 accent-[#0070E0]"
              />
              <span>{pinEnabled ? 'PIN Enabled' : 'PIN Disabled'}</span>
            </label>
          </div>

          {pinEnabled && (
            <>
              <div>
                <FieldLabel label="4-Digit Security PIN" required />
                <input
                  type="password"
                  maxLength={4}
                  pattern="\d{4}"
                  value={appPin}
                  onChange={(e) => setAppPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  className={monoInputClass}
                />
              </div>
              <div className="flex items-end">
                <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 pb-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={biometricEnabled}
                    onChange={(e) => setBiometricEnabled(e.target.checked)}
                    className="w-4 h-4 accent-[#0070E0]"
                  />
                  <span>Enable Quick Biometric / Device Unlock Option</span>
                </label>
              </div>
            </>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          {db.settings.pinEnabled ? (
            <button
              type="button"
              onClick={lockApp}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Lock App Now</span>
            </button>
          ) : (
            <div />
          )}
          <button
            type="submit"
            className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] rounded-xl"
          >
            Save Settings
          </button>
        </div>
      </form>

      {/* Android APK Project Download & Install */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0070E0] flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#002E6E] font-display">
                {lang === 'mr' ? 'Android APK प्रोजेक्ट डाउनलोड' : 'Android APK Project & App Install'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {lang === 'mr'
                  ? 'Android Studio / Capacitor मधून APK तयार करण्यासाठी संपूर्ण सोर्स कोड प्रोजेक्ट (.zip) डाउनलोड करा.'
                  : 'Download the complete Capacitor + Android Studio source project (.zip) to compile an installable .apk, or install directly as an offline Android PWA.'}
              </p>
            </div>
          </div>
          <PWAInstallButton variant="card" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          <div>
            <FieldLabel label="Android App Name" />
            <input
              type="text"
              value={apkAppName}
              onChange={(e) => setApkAppName(e.target.value)}
              placeholder="KoshPay Finance"
              className={inputBaseClass}
            />
          </div>
          <div>
            <FieldLabel label="Android Package ID" />
            <input
              type="text"
              value={apkPackageId}
              onChange={(e) => setApkPackageId(e.target.value)}
              placeholder="com.koshpay.finance"
              className={monoInputClass}
            />
          </div>
          <div>
            <FieldLabel label="App Version" />
            <input
              type="text"
              value={apkVersion}
              onChange={(e) => setApkVersion(e.target.value)}
              placeholder="1.0.0"
              className={monoInputClass}
            />
          </div>
        </div>

        <div className="p-3.5 bg-[#F4F7FB] border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1.5">
          <p className="font-semibold text-[#002E6E]">
            {lang === 'mr'
              ? 'तुमच्या फोनवर Android App / APK कसे मिळवावे:'
              : 'How to get the Android .apk / App on your phone:'}
          </p>
          <p>
            <strong>1. {lang === 'mr' ? 'Android वर थेट Install (APK शिवाय):' : 'Instant Android App (No build needed):'}</strong>{' '}
            {lang === 'mr'
              ? 'खालील App URL मोबाईल Chrome मध्ये उघडा आणि ⋮ Menu → Install app / Add to Home screen वर क्लिक करा.'
              : 'Open your App URL in Chrome on Android and tap Menu (⋮) → Install app / Add to Home screen.'}
          </p>
          <p>
            <strong>2. {lang === 'mr' ? 'ऑनलाईन .APK तयार करा (PWABuilder):' : 'Online .APK Generator (PWABuilder):'}</strong>{' '}
            {lang === 'mr'
              ? 'App URL कॉपी करून pwabuilder.com वर पेस्ट करा आणि Android Package (.apk) डाउनलोड करा.'
              : 'Copy the App URL below, paste it into pwabuilder.com, and download a signed Android .apk package.'}
          </p>
          <p>
            <strong>3. {lang === 'mr' ? 'Cloud / Android Studio APK Build:' : 'Cloud / Android Studio APK Build:'}</strong>{' '}
            {lang === 'mr'
              ? 'डाउनलोड केलेली ZIP फाईल GitHub वर टाकून Actions मधून किंवा Android Studio मधून app-debug.apk तयार करा.'
              : 'Upload the ZIP to GitHub to build via .github/workflows/build-apk.yml, or build locally via BUILD_APK_GUIDE.md.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setShowApkGuide(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#002E6E] bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors min-h-[44px]"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#0070E0]" />
              <span>
                {lang === 'mr' ? 'APK तयार करण्याची माहिती पहा' : 'Generate APK Instructions'}
              </span>
            </button>
            <button
              type="button"
              onClick={async () => {
                const appUrl = window.location.origin;
                try {
                  await navigator.clipboard.writeText(appUrl);
                  setFeedback({
                    type: 'success',
                    message:
                      lang === 'mr'
                        ? `App URL कॉपी झाली: ${appUrl}`
                        : `Copied App URL (${appUrl}) — paste into Chrome Android or pwabuilder.com to generate an .apk.`,
                  });
                } catch {
                  setFeedback({
                    type: 'error',
                    message: `Copy this URL manually: ${appUrl}`,
                  });
                }
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#002E6E] bg-slate-100 hover:bg-blue-50 rounded-xl transition-colors min-h-[44px]"
            >
              <Copy className="w-3.5 h-3.5 text-[#0070E0]" />
              <span>{lang === 'mr' ? 'App URL कॉपी करा' : 'Copy App URL'}</span>
            </button>
          </div>
          <button
            type="button"
            disabled={isExportingApk}
            onClick={async () => {
              setIsExportingApk(true);
              setFeedback(null);
              try {
                const res = await downloadAndroidApkProjectZip({
                  appName: apkAppName,
                  packageId: apkPackageId,
                  versionName: apkVersion,
                  versionCode: 1,
                });
                setFeedback({
                  type: 'success',
                  message: `Downloaded ${res.fileName} (${res.fileCount} project files). Open BUILD_APK_GUIDE.md inside the ZIP to build your .apk.`,
                });
              } catch (err) {
                setFeedback({
                  type: 'error',
                  message:
                    err instanceof Error
                      ? err.message
                      : 'Failed to package Android APK project archive.',
                });
              } finally {
                setIsExportingApk(false);
              }
            }}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#0070E0] hover:bg-[#005BB5] disabled:opacity-60 rounded-xl transition-colors min-h-[44px]"
          >
            <Download className="w-4 h-4" />
            <span>
              {isExportingApk ? 'Packaging APK Project...' : 'Download APK Project (.zip)'}
            </span>
          </button>
        </div>
      </div>

      <ApkInstructionsModal
        open={showApkGuide}
        onClose={() => setShowApkGuide(false)}
        lang={lang}
        appName={apkAppName}
        packageId={apkPackageId}
        version={apkVersion}
        isExportingApk={isExportingApk}
        onDownloadZip={async () => {
          setIsExportingApk(true);
          setFeedback(null);
          try {
            const res = await downloadAndroidApkProjectZip({
              appName: apkAppName,
              packageId: apkPackageId,
              versionName: apkVersion,
              versionCode: 1,
            });
            setFeedback({
              type: 'success',
              message: `Downloaded ${res.fileName} (${res.fileCount} project files).`,
            });
          } catch (err) {
            setFeedback({
              type: 'error',
              message:
                err instanceof Error
                  ? err.message
                  : 'Failed to package Android APK project archive.',
            });
          } finally {
            setIsExportingApk(false);
          }
        }}
      />

      {/* Backup & Restore */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-base font-bold text-[#002E6E] font-display">
            Offline Backup &amp; Database Restore
          </h3>
          <span className="text-xs text-slate-500 font-mono-num">
            Auto-saved locally: {formatDateTime(db.settings.lastAutoBackupAt)}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => {
              exportBackupJSON();
              setFeedback({ type: 'success', message: 'Full JSON database backup downloaded.' });
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#002E6E] hover:bg-[#001F4D] rounded-xl"
          >
            <Download className="w-4 h-4" />
            <span>Manual Backup (.json)</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl"
          >
            <Upload className="w-4 h-4" />
            <span>Restore Backup (.json)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              resetDatabase(true);
              setFeedback({ type: 'success', message: 'Demo dataset loaded.' });
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset to Demo Data</span>
          </button>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-xl"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear All Data</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  resetDatabase(false);
                  setConfirmClear(false);
                  setFeedback({ type: 'success', message: 'All records cleared.' });
                }}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl"
              >
                Confirm Erase
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="px-3 py-2 text-xs font-medium text-slate-600"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Transaction Audit History */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-200">
          <h3 className="text-sm font-bold text-[#002E6E]">
            Transaction &amp; Security Audit History ({db.auditLogs.length})
          </h3>
        </div>
        <div className="divide-y divide-slate-100 max-h-[300px] overflow-y-auto text-xs">
          {db.auditLogs.length === 0 ? (
            <div className="p-6 text-center text-slate-500">No audit events recorded yet.</div>
          ) : (
            db.auditLogs.slice(0, 40).map((log) => (
              <div key={log.id} className="px-5 py-3 flex items-start justify-between gap-4">
                <div>
                  <span className="font-mono-num font-semibold text-[#002E6E]">{log.action}</span>
                  <span className="text-slate-400 mx-1.5">·</span>
                  <span className="font-medium text-slate-700">{log.module}</span>
                  <span className="text-slate-400 mx-1.5">·</span>
                  <span className="font-mono-num text-slate-500">{log.entityId}</span>
                  <p className="text-slate-600 mt-0.5">{log.summary}</p>
                </div>
                <span className="font-mono-num text-[11px] text-slate-400 whitespace-nowrap">
                  {formatDateTime(log.timestamp)}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
